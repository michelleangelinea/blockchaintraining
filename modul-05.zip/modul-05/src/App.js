import React, { useEffect, useState } from 'react';
import logo from './logo.svg';
import './App.css';
import { ethers } from 'ethers';

const contractAddress = '0xe4EE33F790f790950E0064E0E5aC474BE36d577F';
const contractABI = [
  "function calculatePrizesProjection() view returns (uint256)",
  "function makeMove(uint256 move)"
];

function App() {
  const [balance, setBalance] = useState(null);
  const [inputAddress, setInputAddress] = useState('');
  const [provider, setProvider] = useState(null);
  const [signer, setSigner] = useState(null);
  const [contract, setContract] = useState(null);
  const [projectionResult, setProjectionResult] = useState(null);

  useEffect(() => {
    const initializeProvider = async () => {
      if (window.ethereum) {
        try {
          await window.ethereum.request({ method: 'eth_requestAccounts' });
          const web3Provider = new ethers.providers.Web3Provider(window.ethereum);
          const signer = web3Provider.getSigner();
          setProvider(web3Provider);
          setSigner(signer);

          const contractInstance = new ethers.Contract(contractAddress, contractABI, signer);
          setContract(contractInstance);
        } catch (error) {
          console.error('Error initializing provider:', error);
        }
      } else {
        console.error('MetaMask not found. Please install MetaMask to use this feature.');
      }
    };

    initializeProvider();
  }, []);

  const getBalance = async () => {
    try {
      if (!provider) return;
      const balance = await provider.getBalance(inputAddress);
      setBalance(ethers.utils.formatEther(balance));
    } catch (error) {
      console.error('Error fetching balance:', error);
    }
  };

  const calculatePrizesProjection = async () => {
    try {
      if (!contract) throw new Error("Contract is not initialized");
      const projection = await contract.calculatePrizesProjection();
      setProjectionResult(ethers.utils.formatEther(projection));
    } catch (error) {
      console.error('Error calculating prizes projection:', error);
    }
  };

  const makeMove = async () => {
    try {
      if (!contract) throw new Error("Contract is not initialized");
  
      const overrides = {
        gasLimit: 500000
      };
  
      const tx = await contract.makeMove(1, overrides);
      await tx.wait();
      console.log('Move made successfully');
    } catch (error) {
      console.error('Error making move:', error);
    }
  };

  return (
    <div className="App">
      <h1>Check ETH Balance</h1>
      <input
        type="text"
        placeholder="Enter contract address"
        value={inputAddress}
        onChange={(e) => setInputAddress(e.target.value)}
      />
      <br></br>
      <br></br>
      <button onClick={getBalance}>Get Balance</button>
      {balance && (
        <div>
          <h2>Balance:</h2>
          <p>{balance} ETH</p>
        </div>
      )}
      <button onClick={calculatePrizesProjection}>Calculate Prizes Projection</button>
      {projectionResult && (
        <div>
          <h2>Prizes Projection:</h2>
          <p>{projectionResult} ETH</p>
        </div>
      )}
      <button onClick={makeMove}>Make Move</button>
    </div>
  );
}

export default App;
